# Firebase Codelab: FriendlyChat

[![Actions Status][gh-actions-badge]][gh-actions]

This is the source code for the Firebase FriendlyChat codelabs. To get started open the codelab instructions:

 - [Build FriendlyChat Codelab](https://codelabs.developers.google.com/codelabs/firebase-android/)
 - [Grow FriendlyChat Codelab](https://codelabs.developers.google.com/codelabs/growfirebase-android)


## How to make contributions?
Please read and follow the steps in the [CONTRIBUTING.md](CONTRIBUTING.md)


## License
See [LICENSE](LICENSE)

[gh-actions]: https://github.com/firebase/codelab-friendlychat-android/actions
[gh-actions-badge]: https://github.com/firebase/codelab-friendlychat-android/workflows/Android%20CI/badge.svg
